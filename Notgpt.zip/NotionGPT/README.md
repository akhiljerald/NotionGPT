## Installation
run the following code in your terminal:
- ```git clone https://github.com/akhiljerald/NotionGPT.git```

terminal 1 :
- ```cd client```
- ```npm install```
- ```npm start```

terminal 2 :
- ```cd server```
- ```npm install```
- ```npm start```

## Prerequisites
- Node.js
- npm
- configure environment variables