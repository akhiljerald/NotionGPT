const {notionController} = require("./notion.controller.js")

module.exports = {
    notionController : notionController

}