const { notionService } = require('./notion.service.js')

module.exports = {
    notionService: notionService
}